import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js";

const $ = id => document.getElementById(id);
let me = null, socket = null, city = null;
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x9bc2d1);
scene.fog = new THREE.Fog(0x9bc2d1, 65, 180);
const camera = new THREE.PerspectiveCamera(65, innerWidth/innerHeight, .1, 300);
const renderer = new THREE.WebGLRenderer({canvas:$("world"),antialias:true});
renderer.setPixelRatio(Math.min(devicePixelRatio,2)); renderer.setSize(innerWidth,innerHeight);
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
scene.add(new THREE.HemisphereLight(0xdceeff,0x64704f,2));
const sun = new THREE.DirectionalLight(0xfff0d2,2.2); sun.position.set(-30,55,25); sun.castShadow=true; scene.add(sun);
const mat = (color, roughness=.85) => new THREE.MeshStandardMaterial({color,roughness});
const ground = new THREE.Mesh(new THREE.PlaneGeometry(220,220),mat(0x68845c)); ground.rotation.x=-Math.PI/2; ground.receiveShadow=true; scene.add(ground);
const roadMat=mat(0x343b43), lineMat=mat(0xe7dfc6), sidewalk=mat(0xb9b7aa);
function slab(w,d,x,z,material,y=.025){const m=new THREE.Mesh(new THREE.BoxGeometry(w,.08,d),material);m.position.set(x,y,z);m.receiveShadow=true;scene.add(m);return m}
slab(220,15,0,0,roadMat); slab(15,220,0,0,roadMat);
for(let i=-100;i<=100;i+=8){slab(2.8,.16,i,0,lineMat,.08);slab(.16,2.8,0,i,lineMat,.08)}
for(let i=-90;i<=90;i+=30){slab(220,2,i,9,sidewalk);slab(220,2,i,-9,sidewalk);slab(2,220,9,i,sidewalk);slab(2,220,-9,i,sidewalk)}
const buildings=[];
function building(x,z,w,d,h,color,label){
 const group=new THREE.Group(); const body=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat(color));body.position.y=h/2;body.castShadow=true;body.receiveShadow=true;group.add(body);
 const roof=new THREE.Mesh(new THREE.BoxGeometry(w+.25,.35,d+.25),mat(0x46515c));roof.position.y=h+.15;group.add(roof);
 const winMat=new THREE.MeshStandardMaterial({color:0x9bc9d6,metalness:.15,roughness:.25});
 for(let y=2;y<h-1;y+=2.5)for(let xx=-w/2+1;xx<w/2-0.5;xx+=2){const win=new THREE.Mesh(new THREE.BoxGeometry(.85,1.15,.08),winMat);win.position.set(xx,y,d/2+.045);group.add(win)}
 group.position.set(x,0,z);scene.add(group);buildings.push(group);
 const sign = new THREE.Mesh(new THREE.BoxGeometry(Math.min(w*.8,5),.7,.12),mat(0xd6b45e));sign.position.set(0,Math.min(h-1,4),d/2+.12);group.add(sign);
}
const colors=[0xd6d1c3,0xb9c6c7,0xd0b99c,0x9cabb4,0xc5c4b9,0x9fae9e];
let seed=17;const rand=()=>{seed=(seed*9301+49297)%233280;return seed/233280};
for(let x=-80;x<=80;x+=20)for(let z=-80;z<=80;z+=20){if(Math.abs(x)<16||Math.abs(z)<16)continue;building(x+(rand()-.5)*5,z+(rand()-.5)*5,8+rand()*5,8+rand()*5,7+rand()*19,colors[Math.floor(rand()*colors.length)])}
building(0,-25,20,14,18,0xd4c7a8); // town hall
// Park and trees
const park=new THREE.Mesh(new THREE.BoxGeometry(24,.12,22),mat(0x4f8a58));park.position.set(-32,.08,-30);scene.add(park);
function tree(x,z){const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.25,.35,2,7),mat(0x76523a));trunk.position.set(x,1,z);scene.add(trunk);const crown=new THREE.Mesh(new THREE.SphereGeometry(1.45,9,7),mat(0x39764b));crown.position.set(x,3,z);crown.castShadow=true;scene.add(crown)}
for(let i=0;i<18;i++)tree(-42+rand()*20,-39+rand()*18);
function avatar(color=0x2c65c8){const g=new THREE.Group();const body=new THREE.Mesh(new THREE.CapsuleGeometry(.48,.9,4,8),mat(color));body.position.y=1.05;body.castShadow=true;g.add(body);const head=new THREE.Mesh(new THREE.SphereGeometry(.32,12,10),mat(0xe2b995));head.position.y=1.95;g.add(head);return g}
const mine=avatar(0x244ed2);scene.add(mine);mine.position.set(0,0,10);
const players=new Map();let yaw=0, pitch=.42, dragging=false,lastX=0,lastY=0;
const keys={};addEventListener("keydown",e=>keys[e.key.toLowerCase()]=true);addEventListener("keyup",e=>keys[e.key.toLowerCase()]=false);
$("world").addEventListener("pointerdown",e=>{dragging=true;lastX=e.clientX;lastY=e.clientY});
addEventListener("pointerup",()=>dragging=false);
addEventListener("pointermove",e=>{if(!dragging)return;yaw-=(e.clientX-lastX)*.005;pitch=Math.max(.18,Math.min(1.05,pitch+(e.clientY-lastY)*.003));lastX=e.clientX;lastY=e.clientY});
function toast(t){$("toast").textContent=t;$("toast").style.display="block";setTimeout(()=>$("toast").style.display="none",2600)}
function addMessage(m){const el=document.createElement("div");el.textContent=`${m.username}: ${m.message}`;$("messages").append(el);$("messages").scrollTop=$("messages").scrollHeight}
async function api(url,body){const r=await fetch(url,{method:body?"POST":"GET",headers:{"Content-Type":"application/json"},body:body?JSON.stringify(body):undefined});const d=await r.json();if(!r.ok)throw Error(d.error||"حدث خطأ");return d}
function updateUser(u){me=u;$("playerName").textContent=u.username;$("wallet").textContent=`المحفظة: ${u.balance} عملة`;}
function updateCity(c){city=c;$("mayor").textContent=`العمدة: ${c.mayor}`;}
async function enter(data){updateUser(data.user);updateCity(data.city);$("auth").style.display="none";connect()}
async function auth(action){$("authError").textContent="";try{const d=await api("/api/"+action,{username:$("username").value,password:$("password").value});await enter(d)}catch(e){$("authError").textContent=e.message}}
$("register").onclick=()=>auth("register");$("login").onclick=()=>auth("login");
$("logout").onclick=async()=>{await api("/api/logout",{});location.reload()};
$("work").onclick=async()=>{try{const d=await api("/api/work",{job:"عامل خدمات"});updateUser(d.user);toast(d.message)}catch(e){toast(e.message)}};
$("vote").onclick=async()=>{const name=prompt("اكتب رقم حساب اللاعب الذي تريد التصويت له:");if(!name)return;try{const d=await api("/api/vote",{candidateId:Number(name)});updateCity(d.city);toast(d.message)}catch(e){toast(e.message)}};
function connect(){socket=io();socket.on("connect_error",e=>toast(e.message));socket.on("world:players",list=>{list.forEach(p=>{if(p.id!==me.id)addPlayer(p)})});socket.on("world:join",addPlayer);socket.on("world:move",p=>{const a=players.get(p.id);if(a){a.position.set(p.x,0,p.z);a.rotation.y=p.rotation}});socket.on("world:leave",id=>{const a=players.get(id);if(a){scene.remove(a);players.delete(id)}$("online").textContent=`متصلون: ${players.size+1}`});socket.on("chat:message",addMessage)}
function addPlayer(p){if(players.has(p.id))return;const a=avatar(0x239b82);a.position.set(p.x,0,p.z);scene.add(a);players.set(p.id,a);$("online").textContent=`متصلون: ${players.size+1}`}
function sendChat(){const v=$("chatInput").value.trim();if(v&&socket){socket.emit("chat:send",v);$("chatInput").value=""}}
$("send").onclick=sendChat;$("chatInput").addEventListener("keydown",e=>{if(e.key==="Enter")sendChat()});
let lastSend=0;
function animate(t){requestAnimationFrame(animate);const forward=(keys.w||keys.arrowup?1:0)-(keys.s||keys.arrowdown?1:0);const side=(keys.d||keys.arrowright?1:0)-(keys.a||keys.arrowleft?1:0);if(forward||side){const speed=.16;mine.position.x+= (Math.sin(yaw)*forward+Math.cos(yaw)*side)*speed;mine.position.z+= (Math.cos(yaw)*forward-Math.sin(yaw)*side)*speed;mine.position.x=Math.max(-98,Math.min(98,mine.position.x));mine.position.z=Math.max(-98,Math.min(98,mine.position.z));mine.rotation.y=Math.atan2(side,forward)+yaw;if(socket&&t-lastSend>70){socket.emit("player:move",{x:mine.position.x,z:mine.position.z,rotation:mine.rotation.y});lastSend=t}}
const target=new THREE.Vector3(mine.position.x,1,mine.position.z);const dist=12;camera.position.set(target.x+Math.sin(yaw)*dist*Math.cos(pitch),target.y+dist*Math.sin(pitch),target.z+Math.cos(yaw)*dist*Math.cos(pitch));camera.lookAt(target);renderer.render(scene,camera)}
requestAnimationFrame(animate);
addEventListener("resize",()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});
(async()=>{try{const d=await api("/api/me");if(d.user)await enter(d)}catch{}})();
